import { Lancamento } from "../model/Lancamento";
import { executarComandoSQL } from "../database/MySql";

export interface LancamentoDbRow {
  id_lancamento: number;
  data: Date;
  descricao: string;
  valor: number;
  id_conta_debito: number;
  id_conta_credito: number;
}

export class LancamentosRepository {

  private rowToLancamento(row: LancamentoDbRow): Lancamento {
    return new Lancamento(
      row.id_lancamento,
      new Date(row.data),
      row.descricao,
      row.valor,
      row.id_conta_debito,
      row.id_conta_credito
    );
  }

  public async Create(lancamento: Lancamento): Promise<Lancamento> {
    const sql = `
      INSERT INTO lancamentos (data, descricao, valor, id_conta_debito, id_conta_credito)
      VALUES (?, ?, ?, ?, ?);
    `;
    const params = [
      lancamento.data,
      lancamento.descricao,
      lancamento.valor,
      lancamento.id_conta_debito,
      lancamento.id_conta_credito,
    ];

    const result = await executarComandoSQL(sql, params);
    const newId = result.insertId;

    const createdLancamento = await this.Select(newId);
    if (!createdLancamento) throw new Error("Não foi possível encontrar o lançamento recém-criado.");

    return createdLancamento;
  }

  public async Select(id: number): Promise<Lancamento | undefined> {
    const sql = "SELECT * FROM lancamentos WHERE id_lancamento = ?;";
    const params = [id];

    const result = await executarComandoSQL(sql, params);
    const row: LancamentoDbRow | undefined = result[0];

    if (row) {
      return this.rowToLancamento(row);
    }
    return undefined;
  }

  public async SelectAll(): Promise<Lancamento[]> {
    const sql = "SELECT * FROM lancamentos;";
    const result = await executarComandoSQL(sql, []);

    return result.map(
      (row: LancamentoDbRow) => this.rowToLancamento(row)
    );
  }

  public async Update(lancamento: Lancamento): Promise<Lancamento | undefined> {
    const sql = `
      UPDATE lancamentos
      SET data = ?, descricao = ?, valor = ?, id_conta_debito = ?, id_conta_credito = ?
      WHERE id_lancamento = ?;
    `;
    const params = [
      lancamento.data,
      lancamento.descricao,
      lancamento.valor,
      lancamento.id_conta_debito,
      lancamento.id_conta_credito,
      lancamento.id_lancamento,
    ];

    await executarComandoSQL(sql, params);
    return this.Select(lancamento.id_lancamento);
  }

  public async Delete(id: number): Promise<boolean> {
    const sql = "DELETE FROM lancamentos WHERE id_lancamento = ?;";
    const params = [id];

    const result = await executarComandoSQL(sql, params);
    return result.affectedRows > 0;
  }

  /**
   * Encontra todos os lançamentos para uma conta específica em um determinado período.
   * @param id_conta O ID da conta (débito ou crédito).
   * @param mes O mês do período.
   * @param ano O ano do período.
   * @returns Uma lista de lançamentos.
   */
  public async findByContaAndPeriodo(id_conta: number, mes: number, ano: number): Promise<Lancamento[]> {
    const sql = `
      SELECT * FROM lancamentos
      WHERE (id_conta_debito = ? OR id_conta_credito = ?)
      AND MONTH(data) = ?
      AND YEAR(data) = ?;
    `;
    const params = [id_conta, id_conta, mes, ano];
    const result = await executarComandoSQL(sql, params);

    return result.map(
      (row: LancamentoDbRow) => this.rowToLancamento(row)
    );
  }
}