
import { Conta } from "../model/Contas";
import { ContaRepository } from "../repository/ContasRepository";

export class ContasService {
    private contasRepository: ContaRepository;

    constructor(contasRepository: ContaRepository) {
        this.contasRepository = contasRepository;
    }

    public async criarConta(conta: Conta): Promise<Conta> {
        // Adicione validações de negócio aqui se necessário
        return this.contasRepository.create(conta);
    }

    public async buscarContaPorId(id: number): Promise<Conta | null> {
        return this.contasRepository.findById(id);
    }

    public async listarContas(): Promise<Conta[]> {
        return this.contasRepository.findAll();
    }

    public async atualizarConta(conta: Conta): Promise<Conta | null> {
        // Adicione validações de negócio aqui se necessário
        return this.contasRepository.update(conta);
    }

    public async deletarConta(id: number): Promise<boolean> {
        return this.contasRepository.deleteById(id);
    }
}