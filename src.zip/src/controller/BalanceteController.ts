// src/controller/BalancetesController.ts

import { Request, Response } from 'express';
import { BalanceteService } from '../service/BalanceteService';
import { Balancete } from '../model/balancete';
import { Controller, Route, Get, Post, Query, Body, TsoaResponse, Res } from 'tsoa';

@Route("balancetes")
export class BalanceteController extends Controller {
    private balanceteService: BalanceteService;

    constructor(balanceteService: BalanceteService) {
        super();
        this.balanceteService = balanceteService;
    }

    @Get()
    public async getBalancete(
        @Res() notFoundResponse: TsoaResponse<404, { message: string }>,
        @Query() mes: number,
        @Query() ano: number
    ): Promise<Balancete[] | void> {
        const balancetes = await this.balanceteService.getBalancetePorPeriodo(mes, ano);
        if (!balancetes || balancetes.length === 0) {
            return notFoundResponse(404, { message: "Balancetes não encontrados para o período especificado." });
        }
        return balancetes;
    }

    @Post("gerar")
    public async postGerarBalancete(
        @Body() body: { mes: number, ano: number }
    ): Promise<{ message: string, data: Balancete[] }> {
        const { mes, ano } = body;
        const novosBalancetes = await this.balanceteService.calcularEGerarBalancete(mes, ano);
        this.setStatus(201);
        return { message: "Balancetes gerados com sucesso.", data: novosBalancetes };
    }
}