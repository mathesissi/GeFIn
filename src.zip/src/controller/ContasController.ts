import { Controller, Get, Post, Put, Delete, Route, Body, Path, TsoaResponse, Res } from 'tsoa';
import { Conta, TipoConta, SubtipoAtivo } from '../model/Contas';
import { ContasService } from '../service/ContasService';

@Route("contas")
export class ContasController extends Controller {
    private contasService: ContasService;

    constructor(contasService: ContasService) {
        super();
        this.contasService = contasService;
    }

    @Post()
    public async criarConta(
        @Body() dadosConta: {
            nome_conta: string;
            tipo_conta: TipoConta;
            codigo_conta: string;
            subtipo_conta?: string;
        }
    ): Promise<Conta> {
        const novaConta = new Conta(
            0, // O ID será gerado pelo repositório
            dadosConta.nome_conta,
            dadosConta.tipo_conta,
            dadosConta.codigo_conta,
            dadosConta.subtipo_conta
        );
        return this.contasService.criarConta(novaConta);
    }

    @Get()
    public async listarContas(): Promise<Conta[]> {
        return this.contasService.listarContas();
    }

    @Get("{id}")
    public async buscarContaPorId(
        @Path() id: number
    ): Promise<Conta | null> {
        return this.contasService.buscarContaPorId(id);
    }

    @Put("{id}")
    public async atualizarConta(
        @Path() id: number,
        @Body() dadosAtualizados: {
            nome_conta?: string;
            tipo_conta?: TipoConta;
            codigo_conta?: string;
            subtipo_conta?: string;
        }
    ): Promise<Conta | null> {
        const contaExistente = await this.contasService.buscarContaPorId(id);
        if (!contaExistente) {
            this.setStatus(404);
            return null;
        }
        return this.contasService.atualizarConta(contaExistente);
    }

    @Delete("{id}")
    public async deletarConta(
        @Path() id: number,
        @Res() notFoundResponse: TsoaResponse<404, { message: string }>
    ): Promise<boolean | void> {
        const sucesso = await this.contasService.deletarConta(id);
        if (!sucesso) {
            return notFoundResponse(404, { message: "Conta não encontrada." });
        }
        this.setStatus(204);
        return true;
    }
}