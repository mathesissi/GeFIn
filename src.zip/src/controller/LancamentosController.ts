import { Controller, Get, Post, Put, Delete, Route, Body, Path, TsoaResponse, Res } from 'tsoa';
import { Lancamento } from '../model/Lancamento';
import { LancamentosService } from '../service/LancamentosService';

@Route("lancamentos")
export class LancamentosController extends Controller {
  private lancamentosService: LancamentosService;

  constructor(lancamentosService: LancamentosService) {
    super();
    this.lancamentosService = lancamentosService;
  }

  @Post()
  public async criarLancamento(
    @Body() dadosLancamento: {
      data: Date;
      descricao: string;
      valor: number;
      id_conta_debito: number;
      id_conta_credito: number;
    }
  ): Promise<Lancamento> {
    return this.lancamentosService.criarLancamento(dadosLancamento);
  }

  @Get()
  public async listarLancamentos(): Promise<Lancamento[]> {
    return this.lancamentosService.listarLancamentos();
  }

  @Get("{id}")
  public async buscarLancamentoPorId(
    @Path() id: number
  ): Promise<Lancamento | undefined> {
    return this.lancamentosService.buscarLancamentoPorId(id);
  }

  @Put("{id}")
  public async atualizarLancamento(
    @Path() id: number,
    @Body() dadosAtualizados: {
      data?: Date;
      descricao?: string;
      valor?: number;
      id_conta_debito?: number;
      id_conta_credito?: number;
    }
  ): Promise<Lancamento | undefined> {
    return this.lancamentosService.atualizarLancamento(id, dadosAtualizados);
  }

  @Delete("{id}")
  public async deletarLancamento(
    @Path() id: number,
    @Res() notFoundResponse: TsoaResponse<404, { message: string }>
  ): Promise<boolean | void> {
    const sucesso = await this.lancamentosService.deletarLancamento(id);
    if (!sucesso) {
      return notFoundResponse(404, { message: "Lançamento não encontrado." });
    }
    this.setStatus(204);
    return true;
  }
}