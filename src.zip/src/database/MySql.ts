import mysql, { Connection, RowDataPacket, OkPacket, ResultSetHeader } from 'mysql2/promise';

const dbConfig = {
    host: 'localhost', // Idealmente, usar process.env
    port: 3306,
    user: 'root', // Idealmente, usar process.env
    password: 'GeFinServer', // Idealmente, usar process.env
    database: 'sgb' // Idealmente, usar process.env
};

export let mysqlConnection: Connection;

export async function inicializarBancoDeDados() {
    const initialConnection = await mysql.createConnection({
        host: dbConfig.host,
        port: dbConfig.port,
        user: dbConfig.user,
        password: dbConfig.password
    });
    await initialConnection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\``);
    await initialConnection.end();

    const pool = mysql.createPool(dbConfig);
    mysqlConnection = await pool.getConnection();

    console.log('Conexão bem-sucedida com o banco de dados MySQL');

    await criarTabelas();
    console.log('Tabelas verificadas/criadas com sucesso.');
}

export async function criarTabelas() {
    console.log('\nVerificando e criando tabelas...');

    await executarComandoSQL(`
        CREATE TABLE IF NOT EXISTS contas (
            id_conta INT AUTO_INCREMENT PRIMARY KEY,
            nome_conta VARCHAR(100) NOT NULL,
            tipo_conta VARCHAR(50) NOT NULL,
            codigo_conta VARCHAR(20) UNIQUE
        );
    `, []);

    await executarComandoSQL(`
        CREATE TABLE IF NOT EXISTS balancetes (
            id_balancete INT AUTO_INCREMENT PRIMARY KEY,
            mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12),
            ano INT NOT NULL,
            id_conta INT NOT NULL,
            saldo_inicial NUMERIC(12,2) NOT NULL,
            saldo_final NUMERIC(12,2) NOT NULL,
            FOREIGN KEY (id_conta) REFERENCES contas(id_conta)
        );
    `, []);

    await executarComandoSQL(`
        CREATE TABLE IF NOT EXISTS lancamentos (
            id_lancamento INT AUTO_INCREMENT PRIMARY KEY,
            data DATE NOT NULL,
            descricao TEXT,
            valor NUMERIC(12,2) NOT NULL,
            id_conta_debito INT NOT NULL,
            id_conta_credito INT NOT NULL,
            FOREIGN KEY (id_conta_debito) REFERENCES contas(id_conta),
            FOREIGN KEY (id_conta_credito) REFERENCES contas(id_conta)
        );
    `, []);

    console.log('Tabelas verificadas e/ou criadas com sucesso.');
}

export function executarComandoSQL(query: string, valores: any[] = []): Promise<any> {
    return new Promise<any>(
        async (resolve, reject) => {
            if (!mysqlConnection) {
                return reject(new Error('A conexão com o MySQL não foi inicializada.'));
            }
            const [resultado] = await mysqlConnection.query(query, valores);
            resolve(resultado);
        }
    );
}