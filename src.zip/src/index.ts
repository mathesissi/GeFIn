import express from 'express';
import { setupSwagger } from './config/Swagger';
import { RegisterRoutes } from './route/routes';
import { criarTabelas } from './database/MySql';

// Importa todos os repositórios, serviços e controladores
import { BalanceteRepository } from './repository/BalanceteRepository';
import { ContaRepository } from './repository/ContasRepository';
import { LancamentosRepository } from './repository/LancamentosRepository';
import { BalanceteService } from './service/BalanceteService';
import { ContasService } from './service/ContasService';
import { LancamentosService } from './service/LancamentosService';
import { BalanceteController } from './controller/BalanceteController';
import { ContasController } from './controller/ContasController';
import { LancamentosController } from './controller/LancamentosController';

const app = express();
const PORT = 3040;

app.use(express.json());

// 1. Cria as instâncias dos repositórios
const contasRepository = new ContaRepository();
const lancamentosRepository = new LancamentosRepository();
const balanceteRepository = new BalanceteRepository();

// 2. Cria as instâncias dos serviços, injetando os repositórios
const contasService = new ContasService(contasRepository);
const lancamentosService = new LancamentosService(lancamentosRepository);
const balanceteService = new BalanceteService(balanceteRepository, contasRepository, lancamentosRepository);

// 3. Cria as instâncias dos controladores, injetando os serviços
const balanceteController = new BalanceteController(balanceteService);
const contasController = new ContasController(contasService);
const lancamentosController = new LancamentosController(lancamentosService);

// 4. Configuração de Roteamento com injeção de dependência
const apiRouter = express.Router();
RegisterRoutes(apiRouter, {
    balanceteController,
    contasController,
    lancamentosController
});

app.use('/api', apiRouter);

// Configuração do Swagger
setupSwagger(app);

async function startServer() {
    try {
        // Garante que as tabelas existem antes de iniciar a API
        await criarTabelas();
        app.listen(PORT, () => console.log("API online na porta: " + PORT));
    } catch (error) {
        console.error("Erro ao iniciar o servidor ou o banco de dados:", error);
        process.exit(1);
    }
}

startServer();